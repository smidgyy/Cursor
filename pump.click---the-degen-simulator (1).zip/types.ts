export interface Upgrade {
  id: string;
  name: string;
  description: string;
  baseCost: number;
  costMultiplier: number;
  effectValue: number;
  effectType: 'click' | 'passive';
  icon: string;
  count: number;
}

export interface FloatingText {
  id: number;
  x: number;
  y: number;
  value: number;
}

export interface GameState {
  balance: number;
  clickPower: number;
  autoClickPower: number;
  marketCap: number; // Flavor text mostly
  bondingCurveProgress: number; // 0 to 100
}