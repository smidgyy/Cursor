import React, { useState, useEffect, useRef } from 'react';
import { Pill } from './components/Pill';
import { INITIAL_UPGRADES, getIcon } from './constants';
import { Upgrade, FloatingText } from './types';
import { Coins, Zap, Activity, TrendingUp, MousePointer2 } from 'lucide-react';

export default function App() {
  // --- State ---
  const [balance, setBalance] = useState<number>(0);
  const [clickPower, setClickPower] = useState<number>(1);
  const [autoClickPower, setAutoClickPower] = useState<number>(0);
  const [upgrades, setUpgrades] = useState<Upgrade[]>(INITIAL_UPGRADES);
  const [floatingTexts, setFloatingTexts] = useState<FloatingText[]>([]);
  const [isClicking, setIsClicking] = useState(false);
  
  // Game loop refs
  const balanceRef = useRef(balance);
  const autoClickPowerRef = useRef(autoClickPower);
  
  // Sync refs for interval
  useEffect(() => {
    balanceRef.current = balance;
    autoClickPowerRef.current = autoClickPower;
  }, [balance, autoClickPower]);

  // --- Game Loop (Passive Income) ---
  useEffect(() => {
    const interval = setInterval(() => {
      if (autoClickPowerRef.current > 0) {
        setBalance(prev => prev + autoClickPowerRef.current);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // --- Handlers ---

  const handlePillClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    // 1. Add balance
    setBalance(prev => prev + clickPower);
    
    // 2. Visual click state
    setIsClicking(true);
    setTimeout(() => setIsClicking(false), 100);

    // 3. Floating Text Logic
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left + (Math.random() * 60 - 30); 
    const y = e.clientY - rect.top;

    const newText: FloatingText = {
      id: Date.now() + Math.random(),
      x,
      y,
      value: clickPower
    };

    setFloatingTexts(prev => [...prev, newText]);

    setTimeout(() => {
      setFloatingTexts(prev => prev.filter(ft => ft.id !== newText.id));
    }, 1000);
  };

  const buyUpgrade = (upgradeId: string) => {
    setUpgrades(prev => prev.map(up => {
      if (up.id !== upgradeId) return up;

      const currentCost = Math.floor(up.baseCost * Math.pow(up.costMultiplier, up.count));
      
      if (balance >= currentCost) {
        setBalance(b => b - currentCost);
        
        if (up.effectType === 'click') {
            setClickPower(cp => cp + up.effectValue);
        } else {
            setAutoClickPower(acp => acp + up.effectValue);
        }

        return { ...up, count: up.count + 1 };
      }
      return up;
    }));
  };

  const marketCap = (balance * 0.00042).toFixed(4);

  return (
    <div className="min-h-screen bg-[#050505] text-white overflow-hidden font-inter selection:bg-green-500 selection:text-black flex flex-col">
      
      {/* --- Background --- */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        {/* Subtle radial gradients */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-green-500/10 blur-[120px] rounded-full mix-blend-screen"></div>
        <div className="absolute bottom-0 right-0 w-[600px] h-[600px] bg-purple-900/10 blur-[100px] rounded-full mix-blend-screen"></div>
        
        {/* Grid overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,black,transparent)]"></div>
      </div>

      {/* --- Header --- */}
      <header className="relative z-20 flex items-center justify-between px-6 py-6 max-w-7xl mx-auto w-full">
        <div className="flex items-center gap-3">
           {/* New Cursor Logo */}
           <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(255,255,255,0.3)] relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-tr from-gray-100 to-gray-300 opacity-50"></div>
              <MousePointer2 className="text-black fill-black relative z-10 transform -rotate-12 translate-y-0.5 translate-x-[-1px]" size={24} />
           </div>
           <div>
              <h1 className="font-bold text-xl tracking-tight leading-none">Pump.Click</h1>
              <span className="text-[10px] text-gray-500 font-mono tracking-widest uppercase">The Degen Sim</span>
           </div>
        </div>
        
        <div className="flex items-center gap-4 bg-white/5 backdrop-blur-md px-4 py-2 rounded-full border border-white/5">
            <span className="text-xs text-gray-400 uppercase tracking-wider font-bold">Mkt Cap</span>
            <span className="font-mono text-green-400 font-bold">${marketCap}k</span>
        </div>
      </header>

      {/* --- Main Content --- */}
      <main className="relative z-10 flex-1 w-full max-w-7xl mx-auto p-6 grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
        
        {/* LEFT: The Arena */}
        <div className="flex flex-col items-center justify-center space-y-12 py-8 lg:py-0">
            
            {/* Stats Display */}
            <div className="text-center relative">
                <div className="absolute -top-12 left-1/2 -translate-x-1/2 text-[100px] font-bold text-white/5 select-none pointer-events-none whitespace-nowrap blur-sm">
                    CURSOR
                </div>
                <h2 className="text-gray-400 text-xs font-bold uppercase tracking-[0.2em] mb-2">Current Balance</h2>
                <div className="flex items-baseline justify-center gap-2">
                    <span className="text-7xl lg:text-8xl font-mono font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-400 drop-shadow-lg">
                        {Math.floor(balance).toLocaleString()}
                    </span>
                </div>
                <span className="text-green-500 font-bold text-lg tracking-wider">$CURSOR</span>
            </div>

            {/* The Pill */}
            <div className="relative w-full flex justify-center py-8">
                 {/* Floating Text Overlay */}
                 {floatingTexts.map(ft => (
                    <div
                        key={ft.id}
                        className="absolute pointer-events-none text-green-400 font-bold text-3xl animate-float z-50 font-mono drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]"
                        style={{ left: `calc(50% + ${ft.x}px)`, top: `calc(50% + ${ft.y - 120}px)` }}
                    >
                        +{ft.value}
                    </div>
                 ))}
                 
                 <div className="relative z-10 transform scale-125 lg:scale-150 transition-transform">
                     <Pill onClick={handlePillClick} isClicking={isClicking} />
                 </div>
            </div>

            {/* Stat Badges */}
            <div className="grid grid-cols-2 gap-4 w-full max-w-md">
                <div className="bg-white/5 backdrop-blur-sm border border-white/5 rounded-2xl p-4 flex flex-col items-center justify-center gap-1 group hover:bg-white/10 transition-colors">
                    <div className="flex items-center gap-2 text-yellow-400 mb-1">
                        <Zap size={16} />
                        <span className="text-xs font-bold uppercase tracking-wider">Click Power</span>
                    </div>
                    <span className="text-2xl font-mono font-bold">{clickPower.toLocaleString()}</span>
                </div>
                <div className="bg-white/5 backdrop-blur-sm border border-white/5 rounded-2xl p-4 flex flex-col items-center justify-center gap-1 group hover:bg-white/10 transition-colors">
                    <div className="flex items-center gap-2 text-blue-400 mb-1">
                        <Activity size={16} />
                        <span className="text-xs font-bold uppercase tracking-wider">Auto Pump</span>
                    </div>
                    <span className="text-2xl font-mono font-bold">{autoClickPower.toLocaleString()} <span className="text-sm text-gray-500">/sec</span></span>
                </div>
            </div>
        </div>

        {/* RIGHT: Upgrade Station */}
        <div className="h-[600px] bg-black/40 border border-white/10 rounded-3xl overflow-hidden flex flex-col backdrop-blur-xl shadow-2xl relative">
            {/* Header */}
            <div className="p-6 border-b border-white/10 bg-white/[0.02] flex justify-between items-center sticky top-0 z-10 backdrop-blur-lg">
                <div>
                    <h3 className="font-bold text-xl flex items-center gap-2">
                        <Coins className="text-purple-400" size={20} /> 
                        Upgrade Station
                    </h3>
                    <p className="text-xs text-gray-500 mt-1">Spend $CURSOR to increase stats</p>
                </div>
                <div className="bg-green-500/10 border border-green-500/20 rounded-full px-3 py-1 flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></div>
                    <span className="text-[10px] font-bold text-green-400 uppercase tracking-wider">Live</span>
                </div>
            </div>
            
            {/* List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
                {upgrades.map(upgrade => {
                    const currentCost = Math.floor(upgrade.baseCost * Math.pow(upgrade.costMultiplier, upgrade.count));
                    const canAfford = balance >= currentCost;
                    const isClickUpgrade = upgrade.effectType === 'click';

                    return (
                        <button
                            key={upgrade.id}
                            onClick={() => buyUpgrade(upgrade.id)}
                            disabled={!canAfford}
                            className={`w-full p-4 rounded-2xl border flex items-center gap-4 transition-all duration-300 group relative overflow-hidden text-left
                                ${canAfford 
                                    ? 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-green-500/30 hover:shadow-[0_4px_20px_rgba(0,0,0,0.2)]' 
                                    : 'bg-transparent border-transparent opacity-40 cursor-not-allowed'
                                }
                            `}
                        >
                            {/* Icon Box */}
                            <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-black font-bold shadow-lg transition-transform group-hover:scale-110 shrink-0
                                ${canAfford ? 'bg-gradient-to-br from-gray-100 to-gray-300' : 'bg-gray-800 text-gray-500'}
                            `}>
                                {getIcon(upgrade.icon, `w-6 h-6 ${canAfford ? 'text-black' : 'text-gray-500'}`)}
                            </div>
                            
                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-center mb-1">
                                    <h4 className="font-bold text-sm lg:text-base group-hover:text-green-400 transition-colors truncate">{upgrade.name}</h4>
                                    <span className="text-[10px] font-mono font-bold bg-black/40 px-2 py-0.5 rounded text-gray-400 border border-white/5 ml-2 whitespace-nowrap">LVL {upgrade.count}</span>
                                </div>
                                
                                {/* Stat Badge + Description */}
                                <div className="flex items-center gap-2 mb-2">
                                     <div className={`text-[10px] font-bold px-1.5 py-0.5 rounded border flex items-center gap-1
                                        ${isClickUpgrade 
                                            ? 'text-yellow-400 bg-yellow-400/10 border-yellow-400/20' 
                                            : 'text-blue-400 bg-blue-400/10 border-blue-400/20'}
                                     `}>
                                        {isClickUpgrade ? <Zap size={10} /> : <Activity size={10} />}
                                        <span>+{upgrade.effectValue} {isClickUpgrade ? 'Click' : 'Auto'}</span>
                                     </div>
                                </div>
                                
                                <p className="text-xs text-gray-400 mb-2 leading-relaxed">{upgrade.description}</p>

                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-1.5 text-sm font-mono font-bold">
                                        <span className={canAfford ? 'text-green-400' : 'text-gray-600'}>
                                            {currentCost.toLocaleString()}
                                        </span>
                                        <span className="text-[10px] text-gray-600 uppercase">$CURSOR</span>
                                    </div>
                                    {canAfford && (
                                        <TrendingUp size={14} className="text-green-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                                    )}
                                </div>
                            </div>
                        </button>
                    );
                })}
            </div>
            
            {/* Bottom Fade */}
            <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-black/60 to-transparent pointer-events-none"></div>
        </div>

      </main>

      {/* --- Footer --- */}
      <footer className="w-full py-4 text-center z-10">
        <p className="text-[10px] text-gray-600 font-mono tracking-widest uppercase opacity-50 hover:opacity-100 transition-opacity">
            Not Financial Advice • Degen responsibly
        </p>
      </footer>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 255, 255, 0.2);
        }
      `}</style>
    </div>
  );
}